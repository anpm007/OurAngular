import React from 'react';
import { Scene, Router, Actions } from 'react-native-router-flux';
import App from './App';
import CarList from './components/CarList';
import IndividualDetails from './components/IndividualDetails';
import firebase from 'firebase';

const RouterComponent = () => {
  return (
    <Router sceneStyle={{ paddingTop: 65 }}>
      <Scene key="auth">
        <Scene sceneStyle={{ paddingTop: 100, backgroundColor:'#3b5998' }} key="login" component={App} title="Please Login"  />
      </Scene>

      <Scene key="main">
        <Scene
          onRight={() => {
            firebase.auth().signOut();
            Actions.auth();
          }}
          rightTitle="Log Out"
          key="carDetails"
          component={CarList}
          title="My Vehicles" />
        <Scene
          key="individualDetails"
          component={IndividualDetails}
          title="My Vehicles" />
      </Scene>

    </Router>
  );
};

export default RouterComponent;
