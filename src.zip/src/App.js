import React , { Component} from 'react';
import { View,Text, TouchableHighlight } from 'react-native';
import { Actions } from 'react-native-router-flux';

import firebase from 'firebase';
import { Header, Button  , Spinner} from './components/common';
import  LoginForm from './components/LoginForm';
// import HubPage from './components/HubPage';
import CarList from './components/CarList';




class App extends Component {
state ={loggedIn: null};
constructor(props) {
  super(props);
}
  componentWillMount(){
    if (firebase.apps.length === 0) {
      firebase.initializeApp({
      apiKey:'AIzaSyB2slUrOxK4WL0ctqImo-1b1xPWfVSp4U8',
      authDomain: 'auth-84c67.firebaseapp.com',
      databaseURL: 'https://auth-84c67.firebaseio.com',
      storageBucket: 'auth-84c67.appspot.com',
      messagingSenderId: '383384429467'
    });
    }
    firebase.auth().onAuthStateChanged((user) => {
      if(user){
        this.setState({loggedIn : true});
      }
      else {
        this.setState({loggedIn : false});
      }
    });
}

renderContent(){

  switch(this.state.loggedIn){
    case true:
      Actions.main();

    case false:
      return<LoginForm />

    default:
    return<Spinner size="large" />
  }

}


  render(){
    return(
      <View>
      {this.renderContent() }
      </View>
    );
  }
}


const styles={
  textStyle:{
  fontSize:20,
  color:'red',
  alignSelf:'center',
  marginTop:20
}

};


export default App;
