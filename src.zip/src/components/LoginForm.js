import React, {Component} from 'react';
import {Text, TouchableHighlight, View} from 'react-native';
import firebase from 'firebase';


import { Button,Card,CardSection,Input,Spinner } from './common';

class LoginForm extends Component {

  constructor(props) {
    super(props);
    this.state = {email: '',password:'', error:'', loading:false};
    this.onButtonPress = this.onButtonPress.bind(this);
  }

  onButtonPress(){
    this.setState({error:'', loading:true});
    firebase.auth().signInWithEmailAndPassword(this.state.email,this.state.password)
    .then(this.onLoginSuccess.bind(this))

     .catch(() => {     // if user login failed then create new account
        firebase.auth().createUserWithEmailAndPassword(this.state.email,this.state.password)
        .then(this.onLoginSuccess.bind(this))
        .catch(this.onLoginFail.bind(this));

     });
  }

  onLoginFail(){
    this.setState({error:'Authentication Failed', loading: false});
  }

  onLoginSuccess(){
    this.setState({
      email:'',
      password:'',
      loading:false,
      error:''
    });
  }

  renderButton(){
    if (this.state.loading){
      return <Spinner size="small" />;
    }

    return(
      <TouchableHighlight onPress={this.onButtonPress}>
     <Text style={styles.textStyle}>Login</Text>
   </TouchableHighlight>
    );
  }

  render(){
    return(
      <View>
        <Text style={styles.loginTextStyles}> My Vehicles </Text>
        <View style={styles.LoginContainerStyles}>
        <Card>
          <CardSection>
            <Input
              placeholder="Email"
              value={this.state.email}
              onChangeText={email => this.setState({email})}
              />

              </CardSection>

              <CardSection>
              <Input
              secureTextEntry
              placeholder="Password"
              value={this.state.password}
              onChangeText={password => this.setState({password})}
              />

              </CardSection>

              <Text style={styles.errorTextStyle}>
              {this.state.error}
              </Text>

              <CardSection style={{ backgroundColor: 'white' }}>
              {this.renderButton()}
              </CardSection>
              </Card>
            </View>
      </View>
    )
  }
}

const styles={
  errorTextStyle:{
  fontSize:20,
  color:'red',
  alignSelf:'center'
  },
  textStyle:{
    fontSize:20,
    height: 36,
    marginLeft: 150,
    color: 'white'
  },
  cardSectionStyle:{
    marginBottom: 20,
    backgroundColor:'red'
  },
  loginTextStyles:{
    color: 'white',
    fontSize: 25,
    alignSelf: 'center',
    fontWeight: 'bold',
    marginBottom: 40,
    fontFamily: 'Verdana'
  }
};

export default LoginForm;
