import React , {PropTypes} from 'react';
import { Text,View,Image,Linking,ScrollView,TouchableHighlight,WebView } from 'react-native';
import Card from './Card';
import CardSection from './CardSection';
import Button from './Button';


const con_now='';
const con_old='';
const pattern='';

const IndividualDetails = ({list}) => {
  const thumbnail_image_vin = "https://i.kinja-img.com/gawker-media/image/upload/s--850PxImK--/c_scale,fl_progressive,q_80,w_800/18dtthtveanfmjpg.jpg";

  const { thumbnailStyle1 ,imageStyle1,headerTextStyle1, headerContentStyle1} = styles;

  const { title,artist,thumbnail_condition, thumb_miles ,image ,accl,brake, url ,model , psv , vin, miles_old,miles_new,condition_old,condition_now} = list;

  if (condition_old == 'Excellent'){
  con_old = 3;
    }
  else if (condition_old == 'Good') {
    con_old = 2;
  }
  else if (condition_old == 'Fair') {
    con_old = 1;
  };

  if (condition_now == 'Excellent'){
  con_now = 3;
    }
  else if (condition_now == 'Good') {
    con_now = 2;
  }
  else if (condition_now == 'Fair') {
    con_now = 1;
  }


  if (accl == 'Excellent'){
pattern="https://spiritualimplications.files.wordpress.com/2013/01/5star.jpg";
    }
  else if (accl == 'Good') {
pattern="https://c1.staticflickr.com/3/2686/4347962723_ffdd4df93d.jpg";
  }
  else if (accl == 'Fair') {
pattern="https://perpetualpages.files.wordpress.com/2015/02/3-out-of-5-stars.png";
  };


  return(
    <ScrollView>
    <Card>

        <CardSection>
          <View>
          <Text style={styles.headerTextStyle1}>{artist} {title} {model}</Text>
          <Image style = {styles.imageStyle1}  source = {{ uri:image }} />
          <Text style={{marginTop:10}} />

          <Text>
            <Text style={{fontWeight: "bold",flex:2}}>VIN :</Text>
            <Text style={{flex:2}}>{vin}</Text>
          </Text>

          <Text>
            <Text style={{fontWeight: "bold"}}>Miles :</Text> {miles_new} Kms
          </Text>

          <Text>
            <Text style={{fontWeight: "bold"}}>Condition :</Text> {condition_now}
          </Text>

          <Text>
            <Text style={{fontWeight: "bold"}}>Old Seller Value :</Text>  $ {psv}
          </Text>

          <Text>
            <Text style={{fontWeight: "bold"}}>Current Seller Value :</Text> $ {psv-(((miles_new-miles_old)*5)+((con_old-con_now)*100))}
          </Text>

            <Text style={{fontWeight: "bold"}}>Driving Pattern :
            <Image style = {{width:120,height:20}} source = {{ uri:pattern }} />
            </Text>



            <CardSection>
            <View>
            <TouchableHighlight onPress={() => Linking.openURL(url)}>
            <Text>Comment on this Car</Text>
            </TouchableHighlight>
            </View>
            </CardSection>




          <Text style={{marginBottom:10}} />
          </View>
        </CardSection>
        </Card>
        </ScrollView>

      );
    };


    const styles = {

      headerContentStyle1: {
        flexDirection: 'column',
        justifyContent: 'space-around',
        borderRadius: 4,
        borderColor: '#ddd',
        borderBottomWidth: 0,
        shadowColor: '#000',
        shadowOffset: { width:0,height:2},
        shadowOpacity: 0.1,
        shadowRadius: 2,
        elevation: 1

      },

      headerTextStyle1: {
          fontSize:35,
          fontFamily:'Baskerville',
          backgroundColor:'#3b5998',
          color:'white'


      },

      imageStyle1:{
        height:400,
        width:350

      },

      thumbnailStyle1:{
        height:18,
        width:30,
        borderColor: 'gray',
        borderWidth:1

      }


    };
    export  default IndividualDetails;
